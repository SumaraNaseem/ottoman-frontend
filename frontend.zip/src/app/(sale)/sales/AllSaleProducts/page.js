import React from 'react'

const AllSaleProducts = () => {
  return (
    <div>AllSaleProducts</div>
  )
}

export default AllSaleProducts